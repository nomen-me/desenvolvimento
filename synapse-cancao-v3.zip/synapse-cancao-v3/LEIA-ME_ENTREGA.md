# Entrega — Workflows Harmonia avulsos (Synapse)

Gerado a partir de `instalar_nomen_completo.sh`, `provisionar_cliente_synapse2.sh` e `synapse_painel_18-09m.html`.
Nenhum workflow foi executado contra a infraestrutura real (sem acesso de rede neste ambiente). **Nenhum está como PASS.**

## Como importar
Os JSONs têm só `name`, `nodes`, `connections`, `settings` (compatível com a API pública do n8n e com o script de importação do provisionamento, que casa por nome, atualiza e ativa). Importar na UI também funciona. Depois: ativar e conferir CORS (ver Pendências, item 5).

## Credenciais / variáveis (nenhuma gravada nos JSONs)
Todas já existem no `/home/ubuntu/n8n/.env` do Harmonia (gravadas pelo instalador) e são lidas por `$env`:

| Variável | Usada por |
|---|---|
| `CHATWOOT_DOMAIN`, `CHATWOOT_API_TOKEN`, `CHATWOOT_ACCOUNT_ID` | WF-01, 02, 03, 04, 11 |
| `CHATWOOT_WHATSAPP_INBOX_ID` | WF-11 (preferência; ver Pendências, item 3) |
| `ERPNEXT_DOMAIN`, `ERPNEXT_API_KEY`, `ERPNEXT_API_SECRET` | WF-02, 06, 08, 09, 10 |
| (nenhuma) | WF-05: Netdata é o container `acorde:19999` na `stack-network`; o Basic Auth fica só no Traefik |

InfinitePay: o handle (InfiniteTag) é lido do DocType `Synapse Credencial Externa`, registro `infinitepay` (campos `metadados.handle`, senão `conta_conectada`). Sem token no workflow.

## Convenções comuns
- Erro real → HTTP 502 (ou 4xx de validação / 424-501 para pendências) com `{sucesso:false, erro, message}`. O Painel lê `message`.
- Mensagens de erro removem URLs e tokens; WF-05 não revela o host interno.
- Config ausente devolve `PENDENTE_CONFIGURACAO_*` explicitamente.
- `$HARMONIA` nos curls = `https://harmonia.<dominio-base>`.

---

## WF-01 — `Synapse — Atendimento — Listar Conversas`
- **Webhook:** `POST /webhook/atendimento/conversas` · arquivo `01_atendimento_conversas.json`
- **Responsabilidade:** lista conversas reais do Harpa (todas as situações, até 10 páginas = 250) e converte para o contrato do Painel.
- **Entrada:** `{}`
- **Saída:** `{"conversas":[{"id":123,"nome":"…","canal":"whatsapp","nao_lida":true,"status":"open","contato":"+55…","ultima_mensagem":"…","atualizado_em":"ISO"}]}`; sem conversas → `{"conversas":[]}`. `canal` ∈ whatsapp/facebook/instagram/website/telegram/sms/outro (o Painel já mapeia).
- **Erros:** 500 `PENDENTE_CONFIGURACAO_CHATWOOT`; 502 Harpa indisponível/401 (nunca `conversas: []`).
- **Timeout/retry:** 15 s, 3 tentativas (GET).
- **Curl:** `curl -sS -X POST "$HARMONIA/webhook/atendimento/conversas" -H 'Content-Type: application/json' -d '{}'`
- **Status:** `ESTRUTURALMENTE_PRONTO_AGUARDANDO_TESTE_REAL`

## WF-02 — `Synapse — Atendimento — Mensagens`
- **Webhook:** `POST /webhook/atendimento/mensagens` · `02_atendimento_mensagens.json`
- **Responsabilidade:** histórico real da conversa (paginado por `before`, até 200 mensagens), contato, CPF e últimos 5 pedidos do Ritmo.
- **Entrada:** `{"conversa_id":123}`
- **Saída:** `{"mensagens":[{"autor":"cliente|agente|sistema","hora":"ISO","texto":"…"}],"cliente":{"nome":"…","cpf":null,"contato":"5521…"},"ultimos_pedidos":[{"id":"SAL-ORD-…"}]}`
- **Fontes:** mensagens/contato = Harpa; CPF = `Customer.tax_id` (só se tiver 11 dígitos); pedidos = `Sales Order` do cliente. Vínculo conversa→cliente = telefone (comparação pelos últimos 9 dígitos). Sem cliente único → `cpf:null`, `ultimos_pedidos:[]` (nunca adivinha).
- **Erros:** 400 `conversa_id` inválido; 404 conversa inexistente; 502 Harpa ou Ritmo indisponível.
- **Curl:** `curl -sS -X POST "$HARMONIA/webhook/atendimento/mensagens" -H 'Content-Type: application/json' -d '{"conversa_id":ID_REAL}'`
- **Status:** `ESTRUTURALMENTE_PRONTO_AGUARDANDO_TESTE_REAL` (vínculo por telefone = premissa a confirmar; ver Pendências, item 4)

## WF-03 — `Synapse — Atendimento — Enviar Mensagem`
- **Webhook:** `POST /webhook/atendimento/enviar` · `03_atendimento_enviar.json`
- **Entrada:** `{"conversa_id":123,"mensagem":"texto"}`
- **Saída:** `{"sucesso":true,"id":<id real da mensagem no Harpa>}`; erro → `{"sucesso":false,"erro":"…"}` com HTTP de erro.
- **Idempotência/retry:** sem retry no POST (reenviar poderia duplicar a mensagem ao cliente). Timeout 15 s.
- **Curl:** `curl -sS -X POST "$HARMONIA/webhook/atendimento/enviar" -H 'Content-Type: application/json' -d '{"conversa_id":ID_REAL,"mensagem":"Mensagem de teste real"}'` e conferir no Harpa.
- **Status:** `ESTRUTURALMENTE_PRONTO_AGUARDANDO_TESTE_REAL`

## WF-04 — `Synapse — Atendimento — Enviar Anexo`
- **Webhook:** `POST /webhook/atendimento/enviar-anexo` (multipart) · `04_atendimento_enviar_anexo.json`
- **Entrada:** campos `conversa_id` + 1 arquivo em `attachments[]`. Mais de um arquivo → 400 (um por requisição; o Painel envia `files[0]`).
- **Saída:** `{"sucesso":true,"id":<id real>}`
- **Detalhes:** o arquivo não é gravado; segue em memória ao Harpa com nome/conteúdo preservados. Sem retry. Timeout 60 s. Limite = `N8N_PAYLOAD_SIZE_MAX` (padrão 16 MB) e limite do Chatwoot.
- **Curl:** `curl -sS -X POST "$HARMONIA/webhook/atendimento/enviar-anexo" -F conversa_id=ID_REAL -F 'attachments[]=@./teste.pdf'`
- **Status:** `ESTRUTURALMENTE_PRONTO_AGUARDANDO_TESTE_REAL`. Nota: o Painel ainda lança erro em `bffEnviarAnexo()`; ligar o Painel a este webhook é alteração do Painel, fora desta ordem.

## WF-05 — `Synapse — Monitoramento — Métricas`
- **Webhook:** `POST /webhook/monitoramento/metricas` · `05_monitoramento_metricas.json`
- **Entrada:** `{"chart":"system.cpu","points":1,"format":"json","after":-1}` (defaults 1/json/-1; `format` só aceita `json`; `chart` só `[A-Za-z0-9_.-]`).
- **Fonte:** `GET http://acorde:19999/api/v1/data` (container `acorde`, compose do instalador).
- **Saída:** `{"labels":[…],"data":[[…]]}` reais do Netdata (aceita `labels/data` no topo ou dentro de `result`). Resposta sem labels/data (ex.: HTML) → 502.
- **Curl:** para cada um de `system.cpu`, `system.ram`, `disk_space._`: `curl -sS -X POST "$HARMONIA/webhook/monitoramento/metricas" -H 'Content-Type: application/json' -d '{"chart":"system.cpu","points":1,"format":"json","after":-1}'`
- **Status:** `ESTRUTURALMENTE_PRONTO_AGUARDANDO_TESTE_REAL` · ver `CONFLITO_DE_CONTRATO` potencial (Pendências, item 2).

## WF-06 — `Synapse — Consumo — Serviços`
- **Webhook:** `POST /webhook/consumo/servicos` · `06_consumo_servicos.json`
- **Entrada:** `{}`
- **Saída atual:** HTTP **501** `{"status":"PENDENTE_FONTE_DE_DADOS","pendencias":[ia, frete, freteVolume],"parcial":{"freteSaldo":"<cache real de Synapse Credencial Externa.saldo>"}}`.
- **Motivo:** nos arquivos não existe fonte de requisições de IA/dia, fretes/semana nem fretes/mês. Nenhum contador foi criado. `freteSaldo` vem do cache existente (provedor `melhorenvio`) e pode estar defasado (`cache_atualizado_em`).
- **Curl:** `curl -sS -X POST "$HARMONIA/webhook/consumo/servicos" -H 'Content-Type: application/json' -d '{}'`
- **Status:** `PENDENTE_FONTE_DE_DADOS`

## WF-08 — `Synapse — Pagamentos PDV — Criar Cobrança`
- **Webhook:** `POST /webhook/pagamentos/pdv/criar-cobranca` · `08_pagamentos_pdv_criar_cobranca.json`
- **Entrada:** `{"valor":100.00}`; opcional `order_nsu` ou `op_id` (chave de idempotência do PDV).
- **Fonte:** `POST https://api.checkout.infinitepay.io/links` (API oficial da central de ajuda InfinitePay). Item único "Venda PDV" em centavos. `webhook_url` omitido (ver Pendências, item 6).
- **Saída:** `{"checkout_url":"…","order_nsu":"…"}`
- **Idempotência/retry:** sem retry; resposta ambígua nunca dispara 2ª cobrança. Reenvio seguro = mesmo `order_nsu`/`op_id`. Sem chave, cada chamada gera um `order_nsu` novo. Timeout 20 s.
- **Erros:** 400 valor inválido; 424 `PENDENTE_CONFIGURACAO_INFINITEPAY` (credencial ausente/desconectada/sem handle); 502 InfinitePay.
- **Curl:** `curl -sS -X POST "$HARMONIA/webhook/pagamentos/pdv/criar-cobranca" -H 'Content-Type: application/json' -d '{"valor":1.00}'`
- **Status:** `ESTRUTURALMENTE_PRONTO_AGUARDANDO_TESTE_REAL`

## WF-09 — `Synapse — Pagamentos PDV — Status`
- **Webhook:** `POST /webhook/pagamentos/pdv/status` · `09_pagamentos_pdv_status.json`
- **Entrada:** `{"order_nsu":"…"}`; opcionais `transaction_nsu`, `slug`.
- **Fonte:** `POST https://api.checkout.infinitepay.io/payment_check`.
- **Saída:** `pago` somente se `success===true` **e** `paid===true`; `paid===false` → `pendente`; qualquer outra coisa → HTTP 502 (nunca `pago`).
- **Curl:** `curl -sS -X POST "$HARMONIA/webhook/pagamentos/pdv/status" -H 'Content-Type: application/json' -d '{"order_nsu":"NSU_DO_WF08"}'` — antes e depois do pagamento real.
- **Status:** `ESTRUTURALMENTE_PRONTO_AGUARDANDO_TESTE_REAL` · ver `CONFLITO_DE_CONTRATO` potencial (Pendências, item 1).

## WF-10 — `Synapse — Fiscal — Emitir NFC-e`
- **Webhook:** `POST /webhook/fiscal/emitir-nfce` · `10_fiscal_emitir_nfce.json`
- **Entrada:** `{"venda_op_id":"…"}` (o que o Painel envia).
- **Comportamento:** confirma a venda no Ritmo (`POS Invoice.synapse_op_id`) e responde 501 `{"status":"pendente","codigo":"PENDENTE_DEPENDENCIA_MECANISMO_FISCAL"}`; o Painel mantém `nfce.status='pendente'`. Nada é emitido/autorizado; sem certificado, XML ou assinatura. Há um nó HTTP **desabilitado e desconectado** marcando o ponto de encaixe.
- **Motivo:** o módulo `brazil_nf` é instalado no Ritmo, mas nenhum endpoint de emissão consta nos arquivos.
- **Curl:** `curl -sS -X POST "$HARMONIA/webhook/fiscal/emitir-nfce" -H 'Content-Type: application/json' -d '{"venda_op_id":"OP_REAL"}'`
- **Status:** `PENDENTE_DEPENDENCIA_MECANISMO_FISCAL` (não é PASS)

## WF-11 — `Synapse — Atendimento — Número WhatsApp`
- **Webhook:** `POST /webhook/atendimento/numero-whatsapp` · `11_atendimento_numero_whatsapp.json`
- **Entrada:** `{}` · **Saída:** `{"numero":"5521999999999"}` (dígitos, do inbox WhatsApp real).
- **Regra:** usa `CHATWOOT_WHATSAPP_INBOX_ID` só se for de fato um inbox WhatsApp; senão o único inbox WhatsApp; nenhum → 404 `PENDENTE_CONFIGURACAO_WHATSAPP`; vários sem preferência válida → 409. Sem fallback para número da Nomen.
- **Curl:** `curl -sS -X POST "$HARMONIA/webhook/atendimento/numero-whatsapp" -H 'Content-Type: application/json' -d '{}'`
- **Status:** `ESTRUTURALMENTE_PRONTO_AGUARDANDO_TESTE_REAL`

## WF-07 — CNPJ
`AGUARDANDO_ARQUIVO_EXISTENTE` — `fiscal_consultar_cnpj.json` não veio nos anexos; **nada foi duplicado**. Importar o existente e conferir `POST /webhook/fiscal/consultar-cnpj`. Observação: no Painel, `bffConsultarCNPJ()` é stub (não encontrei a função no trecho lido; conferir) — ligar é alteração do Painel, fora desta ordem.

---

## Pendências e riscos (para o desenvolvedor principal)

1. **`CONFLITO_DE_CONTRATO` potencial — WF-09.** O Painel envia só `{order_nsu}`, mas a documentação da InfinitePay para `payment_check` lista `transaction_nsu` e `slug`, que só existem após o pagamento (redirect/webhook). Se a API exigir esses campos, o polling do PDV não funciona só com `order_nsu`; a saída correta é um receptor do webhook de confirmação gravando o pago no Ritmo. O workflow não finge: erro → 502.
2. **`CONFLITO_DE_CONTRATO` potencial — conversão de RAM/disco no Painel.** `calcularPercentualNetdata` trata `linha[1]` como *usado* e `linha[2]` como *livre*. Pela documentação do Netdata, `system.ram` costuma vir como `time, free, used, …` e `disk_space._` como `time, avail, used, …` (invertido). **Não alterei o formato** (a ordem proíbe); conferir `labels` no payload real do teste do WF-05. Conferir também se `disk_space._` existe no container `acorde` (só `/proc`, `/sys` montados, sem `/` do host).
3. **`CHATWOOT_WHATSAPP_INBOX_ID=1`** gravado pelo instalador tende a apontar para o webchat "Site Synapse" (inbox criado no provisionamento). O WF-11 já se protege, mas o valor está incoerente.
4. **WF-02:** o vínculo conversa→Customer por telefone é premissa minha (os arquivos não definem outro). Confirmar/ajustar.
5. **CORS/`$env`:** (a) o instalador não configura CORS no Harmonia; copiar o `allowedOrigins` do webhook do `fiscal_consultar_cnpj.json` existente (não incluí para não inventar origem). (b) n8n 2.x bloqueia `$env` em nós por padrão (`N8N_BLOCK_ENV_ACCESS_IN_NODE=true`); o `.env` do instalador não define isso. Se os workflows existentes já usam `$env`, está resolvido; senão, adicionar `N8N_BLOCK_ENV_ACCESS_IN_NODE=false` ao `.env` do Harmonia.
6. **InfinitePay `webhook_url`:** o path do webhook de confirmação no Harmonia não consta nos arquivos. Se já existir, informe o path e eu incluo no payload.
7. **Handle InfinitePay:** a origem do handle na credencial (`metadados.handle` ou `conta_conectada`) é premissa; o campo `nome_loja` do Painel pode não ser a InfiniteTag.
8. **Rede:** o Harmonia chama o Harpa por `CHATWOOT_DOMAIN` (URL pública). Os caminhos `/api/v1` estão liberados no Traefik.

## Ordem sugerida de teste real
WF-01 → 02 → 03 → 04 → 05 (3 charts) → 11 → 08 → 09 → (06 e 10 aguardam fonte/mecanismo).
