# Semaphore + n8n + Painel + Canção — Relatório v3

## Veredito: **FAIL — AUTOMATIZAÇÃO INCOMPLETA** (por enquanto)

Dois motivos objetivos, ambos fora do que eu consigo fechar sozinho:

1. **Os instaladores ainda não foram alterados.** Você vai entregar versões novas (PDV full); aplico tudo nelas, não nas antigas. Nenhum instalador foi executado em VPS limpa.
2. **Nenhuma VPS real foi usada.** Provei cada elo com o **software real fixado** (Semaphore v2.19.12, n8n 2.40.7, Ansible, Frappe/ERPNext, Lyra), mas num sandbox. O último salto (Ansible → SSH → VPS do cliente → instalar o Synapse → DNS/domínio → Painel no ar) **não foi executado**.

## 1. O que está provado, com componentes reais

| Elo | Como foi provado | Resultado |
|---|---|---|
| Script de configuração do Semaphore (`semaphore.zip`) | Rodado do zero contra o **Semaphore v2.19.12 real** | **PASS**: projeto, 4 chaves, repositório, Environment, Inventory, 4 templates, agendamento, 2 Integrations, 6 extractors, 2 aliases |
| Idempotência | 2ª execução | **Contagens idênticas** (`semaphore_objetos_run1/2.json`), "criados: nada", token preservado |
| Integration n8n↔Semaphore | Disparo real, `auth_method: token` | Token errado: **0 tasks**. Token certo: task `success`. Contrato violado: task `error` (assert do playbook) |
| Parâmetros chegam ao Ansible | Saída da task | `INTEGRACAO_OK vps_ip=203.0.113.10 dominio=lojademo.com.br nome_loja=Loja Demo` |
| **n8n real → Semaphore → Ansible** | Webhook do n8n 2.40.7 → Integration → task | 401/400 para pedidos inválidos (sem criar task); 202 + task `success` para o válido (`e2e_n8n_semaphore_ansible.log`) |
| Playbook real `Provisionar Cliente` | Disparado pela Integration | Valida parâmetros, registra o host, **para só no SSH** (não há VPS cliente) |
| 23 workflows no n8n real | Import/ativação pela **API pública** (como o instalador) | 23/23 ativos |
| Ciclo da Canção | Ritmo (HTTP real) → relay → n8n → ACK/gate → agregação → Lyra real | ACK+AGGREGATE; `UNKNOWN`/`IGNORE` → PROCESSED; `MAX_EVENTS` → flush imediato com 3 envelopes → Lyra; DLQ após 3 retries → `RECONCILING`; `intent_expired` → notificação entregue ao Chatwoot *(stand-in)* (`e2e_cancao_stack_real.log`) |
| Queda da Lyra | Lyra desligada/religada | Evento fica `ACK` (não PROCESSED), recupera ao religar, **1** notificação, sem duplicar (`e2e_queda_lyra.log`) |

Testes unitários: Ritmo 37, gate 16, contrato n8n→Semaphore 13, Lyra 15 — todos OK.

## 2. Defeitos reais encontrados (só apareceram executando o software real)

**Pré-existentes no que você me deu**
- **`configurar_semaphore_synapse.sh` falhava no Semaphore v2.19.12.** (a) Faltava `project_id` no corpo de todo POST/PUT; (b) o ID do template vinha poluído com log, e `registrar_pendente` dentro de `$(...)` era perdido (falha de template não derrubaria o instalador); (c) o Inventory era criado com `become_key` do tipo SSH, o que a v2.19.12 recusa (`access key type not supported for ansible become user`) e **fazia toda task falhar**; (d) usava `semaphoreui/semaphore:latest`; (e) exigia `GOOGLE_PLACES_API_KEY`, que nenhum playbook consome; (f) dependia de bundle local ou de repo privado.
- **Os 71 nós HTTP dos workflows existentes usam `typeVersion 4` com `requestMethod`.** No n8n 2.40.7 o parâmetro é `method`; sem ele o n8n envia **GET** (visto no proxy: um `outbox_ack` saiu como GET com corpo). Corrigi nos 71 e nos meus 20. **Isso altera o comportamento dos workflows existentes; confirme.**
- **`Lyra_L3_automacao.json` é recusado pelo n8n** (conexões apontam para nomes antigos dos 3 nós `(PENDENTE)`). Alinhei os nomes. Os 3 nós continuam sendo *stubs* intencionais.
- O endpoint de disparo da Integration responde **204 mesmo com token errado**; só cria task com o token certo. Validar pelo HTTP é impossível; a validação confere a **task**.
- O repo `painel` (que o instalador clona) **não é** o Painel oficial. O oficial é `painel-synapse`. **O patch de Aprovações da entrega anterior foi aplicado no repo errado**; refeito sobre `painel-synapse@61615af`.
- O Semaphore só escuta em `127.0.0.1` e na `semaphore-network`; o n8n (`stack-network`) **não o alcança**. Na portagem o Semaphore entra também na `stack-network`.

**Meus (corrigidos)**
- Fluxo de dados: após um nó HTTP o `$json` vira a resposta do Ritmo, e `gate`/`env` se perdiam. Eventos agregados e de controle eram marcados PROCESSED sem agregar nem ir à Lyra. Corrigido (nó "Contexto do Evento").
- `webhook` pelo CLI não recebe `webhookId`; pela API pública (caminho do instalador) o n8n o atribui sozinho, então os workflows estão corretos.
- Os webhooks só estão registrados alguns segundos **depois** do `healthz`; a validação do instalador precisa de retentativas.

## 3. O que fiz para cumprir a ordem (§3–§8, §12–§14)

- **Integration criada por código**, pela API oficial (`/project/{id}/integrations`, `/values`, `/aliases`), idempotente por nome, com contrato `vps_ip`, `dominio`, `nome_loja` (todos consumidos pelos playbooks).
- **Segredo** no Key Store do Semaphore; o valor vive só em `integracao_n8n.env` (600) e no `.env` do n8n. Nunca no workflow, HTML ou repo.
- **Workflow `Synapse — Provisionar Cliente (Semaphore)`**: autentica (`X-Synapse-Provision-Token`), valida o contrato (IPv4, FQDN, `nome_loja` sem `"` `$` `` ` `` `\`, porque vai à linha de comando do playbook), dispara a Integration. O n8n não guarda estado; cada cliente é identificado pelo corpo.
- **Template `Validar Integracao`** (executa só em localhost, mesmo contrato): permite o instalador provar n8n→Semaphore→Ansible sem tocar em VPS de cliente.
- **Painel oficial** (`painel-synapse`, base `61615af`): aba Aprovações (Aprovar/Rejeitar) com a sessão/CSRF do Ritmo, via patcher com âncoras verificadas.

## 4. O que ainda falta (nada disto está feito)

1. **Portar tudo para os instaladores novos** (você vai enviar). Plano: payload com sha256 contendo app do Ritmo, workflows (4 novos + 19 corrigidos), bundle do Semaphore corrigido, patch da Lyra e patcher do Painel; `*_DOMAIN` só host; Semaphore também na `stack-network`; gravar no `.env` do n8n `SEMAPHORE_INTERNAL_URL`, `SEMAPHORE_INTEGRACAO_*` e `SYNAPSE_PROVISION_TOKEN`; Painel de `painel-synapse` **fixado por commit**; `err()`⇒`INSTALL = FAIL`; validação funcional com retentativas.
2. **Execução em VPS limpa**: instalar o ambiente Nomen, provisionar um cliente de teste, repetir o provisionamento (idempotência), A–J.
3. **Pré-requisito que o código não resolve:** a chave pública `ssh-clientes` precisa estar autorizada na VPS do cliente **na criação da VPS** (o script a gera e a expõe), e o DNS dos 7 subdomínios precisa apontar para ela antes do provisionamento.
4. **Gemini real** (esta máquina não alcança a API: "Host not in allowlist") e **Chatwoot real** (usei um receptor HTTP).
5. O **Painel não foi executado em navegador**.

## 5. Preciso de você para a portagem

Os dois instaladores novos e, se mudaram: o commit do `painel-synapse`, o commit do `json` e a lista de DocTypes/eventos novos do PDV (para decidir o que entra no gate; hoje todo evento fora do contrato é `UNKNOWN`: registrado e sem autonomia).
