from frappe.model.document import Document


class SynapseEstado(Document):
    pass
