from frappe.model.document import Document


class SynapseAutonomia(Document):
    pass
