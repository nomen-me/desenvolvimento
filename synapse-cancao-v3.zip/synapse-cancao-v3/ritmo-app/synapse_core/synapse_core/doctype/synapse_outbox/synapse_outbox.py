from frappe.model.document import Document


class SynapseOutbox(Document):
    pass
