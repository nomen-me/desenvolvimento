from frappe.model.document import Document


class SynapseOperacao(Document):
    pass
