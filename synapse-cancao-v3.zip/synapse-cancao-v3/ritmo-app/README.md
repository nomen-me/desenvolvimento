# synapse_core

App Frappe do Ritmo que implementa a autoridade de estado da Cancao da Lyra.
